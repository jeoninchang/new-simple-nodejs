module.exports = {
  host: '[수강생의 RDS 주소]',
  user: '[수강생의 RDS user]',
  password: '[수강생의 RDS password]',
  database: '[수강생의 RDS DB]'
}
